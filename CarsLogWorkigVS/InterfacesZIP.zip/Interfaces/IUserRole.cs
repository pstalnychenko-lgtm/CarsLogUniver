﻿using CarsLogWorkig.Models;
using System;
using System.Collections.Generic;
using System.Text;

namespace CarsLogWorkigVS.Interfaces
{
    public interface IUserRole
    {
        UserRole Role { get; }  
        

    }
}
