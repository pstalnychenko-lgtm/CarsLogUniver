﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CarsLogWorkigVS.Interfaces
{
    public interface IUserBaseDate
    {
        
        DateTime DateOfRegistration { get; }
        DateTime DateOfLastActivity { get; set; }
    }
}
