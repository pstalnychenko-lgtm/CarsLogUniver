﻿using CarsLogWorkig.Models;
using System;
using System.Collections.Generic;
using System.Text;

namespace CarsLogWorkigVS.Interfaces
{
    public interface IUserSex
    {
        UserSex UserSex { get;} 
    }
    
}
