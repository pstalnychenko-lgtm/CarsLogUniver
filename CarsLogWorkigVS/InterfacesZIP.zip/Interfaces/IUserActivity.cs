﻿using CarsLogWorkig.Models;
using System;
using System.Collections.Generic;
using System.Text;

namespace CarsLogWorkigVS.Interfaces
{
    public interface IUserActivity
    {
        IsActiveUser IsActive { get; set; }
    }
}
