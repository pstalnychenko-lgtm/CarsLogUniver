using CarsLogWorkig.Models;
using System;

namespace CarsLogWorkigVS.Interfaces
{
    
    public interface IAdmin : IUserRights
    {
        void DeactivateUser(User user);
        void ActivateUser(User user);
        void AssignRole(User user, UserRole role);
        bool CanViewUserDetails(User user);
    }
}
