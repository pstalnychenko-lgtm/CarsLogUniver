﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CarsLogWorkigVS.Interfaces
{
    public interface IUserArgumentCheck
    {
        bool CheckUserAgreement { get; }
    }
}
