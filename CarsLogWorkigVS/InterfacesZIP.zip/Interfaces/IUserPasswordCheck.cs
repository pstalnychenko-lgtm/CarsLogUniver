﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CarsLogWorkigVS.Interfaces
{
    public interface IUserPasswordCheck
    {
        string PasswordHash { get; }
        bool VerePassword { get; set; }
    }    
}
