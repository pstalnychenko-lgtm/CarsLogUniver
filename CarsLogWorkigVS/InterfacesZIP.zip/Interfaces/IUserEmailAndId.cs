﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CarsLogWorkigVS.Interfaces
{
    public interface IUserEmailAndId
    {
        
        Guid Id { get; }
    }
}
