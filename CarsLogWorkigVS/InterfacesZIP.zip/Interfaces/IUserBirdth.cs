﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CarsLogWorkigVS.Interfaces
{
    public interface IUserBirdth
    {
        DateTime DateOfBirth { get; set; }
        string DateOfBirthFormatted { get; }
    }
}
